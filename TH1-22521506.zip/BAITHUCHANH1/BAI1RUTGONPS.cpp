
#include<iostream>

using namespace std;

struct PhanSo {
    int tu, mau;
};

int UCLN(int a, int b) {
    if(b==0) return a;
    return UCLN(b, a%b);
}

void RutGonPhanSo(PhanSo &ps) {
    int ucln = UCLN(ps.tu, ps.mau);
    ps.tu /= ucln;
    ps.mau /= ucln;
    if (ps.mau==1) cout<<"Phan so la: "<<ps.tu;
	else if (ps.mau==-1) cout<<"Phan so la: "<<-ps.tu;
	else if (ps.mau<0) cout<<"Phan so la: "<<-ps.tu<<"/"<<-ps.mau;
	else cout<<"Phan so la: "<<ps.tu<<"/"<<ps.mau;
}
void nhapPhanSo(PhanSo &ps) {
    cout << "Nhap tu so: ";
    cin >> ps.tu;
    do {
        cout << "Nhap mau so: ";
        cin >> ps.mau;
    } while (ps.mau == 0);
}
int main() {
    PhanSo ps; 
	nhapPhanSo(ps);  
    RutGonPhanSo(ps);    
    return 0;
}

