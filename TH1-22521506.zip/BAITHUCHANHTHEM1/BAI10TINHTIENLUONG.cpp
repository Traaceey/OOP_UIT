#include <iostream>
using namespace std;
void Nhap(int &v, int &r){
   do	{cout<<"Nhap gio vao lam: ";
	cin>>v;}
	while (v<0||v>18);	
	do {cout<<"Nhap gio ra ve: ";
	cin>>r;}
	while (r<0 || r>18);
	}
int Tinhtien(int v, int r){
	int t;
	if (v<=12 && r<=12)
		 t = (r-v)*6000;
	else if (v>12 && r>12)
		t = (r-v)*7500;
	else if (v<= 12 && r>12)
		t = (12-v)*6000+(r-12)*7500;
	return t;
}
int main(){
	int v, r;
	Nhap(v,r);
	cout<<Tinhtien(v,r);
	return 0;
}
	
